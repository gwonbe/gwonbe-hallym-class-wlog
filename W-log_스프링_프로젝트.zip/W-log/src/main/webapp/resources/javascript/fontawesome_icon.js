// 포토 날씨 분류에 따라 아이콘 삽입

var iconTag = document.getElementById("fontawesome-weather-icon");

function getWeatherIcon(obj){

	var text = obj.innerText;
	
	switch(text){
		case "sun":
			obj.innerHTML = "<i class='fa-solid fa-sun'></i>";
			break;
		case "cloud":
			obj.innerHTML = "<i class='fa-solid fa-cloud'></i>";
			break;
		case "wind":
			obj.innerHTML = "<i class='fa-solid fa-wind'></i>";
			break;
		case "bolt":
			obj.innerHTML = "<i class='fa-solid fa-bolt'></i>";
			break;
		case "umbrella":
			obj.innerHTML = "<i class='fa-solid fa-umbrella'></i>";
			break;
		case "snowflake":
			obj.innerHTML = "<i class='fa-solid fa-snowflake'></i>";
			break;
		default:
			obj.innerHTML = "날씨를 선택하지 않았습니다.";
	}
	
}

getWeatherIcon(iconTag);
