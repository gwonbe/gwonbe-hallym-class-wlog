var resultTbody = document.getElementById("dangiyebo_tbody");

// 달력 형태

$("#datepick").datepicker({
	dateFormat: "yymmdd",
	minDate: "-1d",
	maxDate: "d",
});

// 달력에서 날짜를 클릭하면 Date 객체 생성

$("#datepick").datepicker("setDate", new Date());

// 조회 버튼을 눌렀을 때

$('form').submit(()=>{
	let tDate = $("#datepick").val();
	searchWeather(tDate);
	return false; // action으로 넘기는 기능을 막는다.
});

// 날씨를 조회해서 테이블을 생성하는 함수

function searchWeather(userDate){
	gridNX = localStorage.getItem("map_GridX");
	gridNY = localStorage.getItem("map_GridY");
	console.log(userDate);
	console.log(`격자 값 : \n nx = ${gridNX} ny = ${gridNY}`)
	$.ajax({
		url: `https://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getVilageFcst?serviceKey=CoxVbzn96oJCQas1QIf7GT79tyBWmB4TStYi72khP26%2BTnNrORVGnfgk7m0PP4QXWiZxIiJrM%2BrG8%2BEhtkgOxQ%3D%3D&pageNo=1&numOfRows=1000&dataType=JSON&base_date=${userDate}&base_time=0500&nx=${gridNX}&ny=${gridNY}`,
		success: function(result){
			//console.log(result);
			let items = result.response.body.items.item;
			let filteredItems = items.filter((item) => {
				return (item.category == 'TMP');
			});
			//console.log(filteredItems);
			makeTable(filteredItems);
		},
	});
}

// 파라미터를 테이블로 출력하는 함수

function makeTable(src){
	
	var arrTemperature = ["온도"];
	var arrTime = [];
	var i = -1;
	var arrPointer = 0;
	
	tbody = "";
	
	src.forEach(item => {
		i++;
		if(i%6 != 0) return; // continue
		tbody += 
			`
			<tr>
				<td>${item.fcstDate.substr(0,4)}년 ${item.fcstDate.substr(4,2)}월 ${item.fcstDate.substr(6,2)}일</td>
				<td>${(item.fcstTime).substr(0, 2)}:00</td>
				<td>${item.fcstValue}°C</td>
			</tr>
			`;
		arrTemperature[arrPointer+1] =  parseInt(item.fcstValue);
		arrTime[arrPointer] = `${item.fcstDate.substr(6,2)}일 ${(item.fcstTime).substr(0, 2)}시`;
		arrPointer++;
	});
	
	resultTbody.innerHTML = tbody;
	
	//console.log(arrTemperature);
	//console.log(arrTime);
	
	// 그래프 출력하기
	var chart_damage = c3.generate({
	    bindto: '#dangiyebo-chart',
	    data: {
	        columns: [arrTemperature],
	        type: 'spline',
	        labels: true,
	    },
	    axis: {
	        x: {
	            type: 'category',
	            categories: arrTime
	        }
	    },
	    color: { pattern: ['#FB9483'] }
	});
	
}

