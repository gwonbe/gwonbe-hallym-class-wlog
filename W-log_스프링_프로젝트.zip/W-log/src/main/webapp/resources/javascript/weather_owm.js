const API_KEY = "d3bc27b6065fe9059c68a57ec415dbcf";

const weatherLocation = document.getElementById("weather-location");
const weatherIcon = document.getElementById("weather-icon");
const weatherValue = document.getElementById("weather-value");

function onGeoOk(position){
    const weatherLat = position.coords.latitude;
    const weatherLon = position.coords.longitude;
    const weatherURL = `https://api.openweathermap.org/data/2.5/weather?lat=${weatherLat}&lon=${weatherLon}&appid=${API_KEY}&units=metric`;
    fetch(weatherURL)
        .then(Response => Response.json()
        .then((data) => {
			weatherLocation.innerHTML = `<b>현재 위치 : ${data.name}</b>`;
			weatherIcon.innerHTML = `<img src="http://openweathermap.org/img/w/${data.weather[0].icon}.png">`;
            weatherValue.innerHTML += ``;
            //weatherValue.innerHTML += `<tr> <th>날씨</th> <td>${data.weather[0].main}</td> </tr>`;
           	weatherValue.innerHTML += `<tr> <th>온도</th> <td>${data.main.temp}&deg;C</td> </tr>`;
            weatherValue.innerHTML += `<tr> <th>기압</th> <td>${data.main.pressure} hPa</td> </tr>`;
            weatherValue.innerHTML += `<tr> <th>습도</th> <td>${data.main.humidity}%</td> </tr>`;
            weatherValue.innerHTML += `<tr> <th>풍속</th> <td>${data.wind.speed} m/s</td> </tr>`;
            weatherValue.innerHTML += `<tr> <th>풍향</th> <td>${data.wind.deg}&deg;</td> </tr>`;
        }));
}
function onGeoError(){
    alert("위치 정보를 불러오지 못했습니다.");
}

navigator.geolocation.getCurrentPosition(onGeoOk, onGeoError);
