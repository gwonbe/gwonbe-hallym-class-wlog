// summernote

$(document).ready(function() {
	$('#summernote').summernote();
});
		
$('#summernote').summernote({
	height: 400, minHeight: null, maxHeight: null, focus: true
});

// 완료 버튼을 누르면 summernote 입력 내용을 출력하기
	
var btn = document.getElementById("btn");
	
function onButtonClick(){
	var content = document.querySelector(".note-editable")
	result.innerHTML = content.innerHTML;
}
	
btn.addEventListener("click", onButtonClick);
	