console.log("kakaomap JS");

// 지도 컨테이너

var mapContainer = 
	document.getElementById('map'),
    mapOption = { 
        center: new kakao.maps.LatLng(37.88630442130734, 127.73572649399448),
        level: 3
    };

// 지도 생성

var map = new kakao.maps.Map(mapContainer, mapOption);

// 클릭한 위치에 표출할 마커

var marker = new kakao.maps.Marker({ 
    position: map.getCenter() 
});

// 지도에 마커 표시

marker.setMap(map);

// 지도에 클릭 이벤트 등록
// 지도를 클릭하면 마지막 파라미터로 넘어온 함수를 호출

kakao.maps.event.addListener(map, 'click', function(mouseEvent) {        
    
    // 클릭한 곳의 위경도 값을 가져오기
    var latlng = mouseEvent.latLng; 
    
    // 위경도 값을 localStorage에 저장하기
    localStorage.setItem("map_Latitude", JSON.stringify(latlng.getLat()));
    localStorage.setItem("map_Longitude", JSON.stringify(latlng.getLng()));
    
    // 마커 위치를 클릭한 위치로 옮기기
    marker.setPosition(latlng);
    
    var message = `위도 : ${latlng.getLat()} / 경도 : ${latlng.getLng()} `;
    var resultDiv = document.getElementById('clickLatlng'); 
    resultDiv.innerHTML = message;
    
});
