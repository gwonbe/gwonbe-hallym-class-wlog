var predictionTr = document.getElementById("prediction_tr");
var codeOfArea = 42; // 지역 코드 : 강원도

// 건강보험공단 질병 예측 서비스
function searchPrediction(){
	for(var i=1; i<=16; i++){
		if(i>=6 && i<=14) continue;
		$.ajax({
			// pageNo=1 : 첫 번째 결과인 춘천만 조회
			url: `https://apis.data.go.kr/B550928/dissForecastInfoSvc/getDissForecastInfo?serviceKey=CoxVbzn96oJCQas1QIf7GT79tyBWmB4TStYi72khP26%2BTnNrORVGnfgk7m0PP4QXWiZxIiJrM%2BrG8%2BEhtkgOxQ%3D%3D&numOfRows=1&pageNo=1&type=json&dissCd=${i}&znCd=${codeOfArea}`,
			success: function(result){
				let dDissCd = result.response.body.items[0].dissCd
				let dRisk = result.response.body.items[0].risk;
				if(dDissCd != null && dRisk != null){
					predictionTr.innerHTML += 
						`<th> 
							<p class='p_dissCd'>${getDissCd(dDissCd)}</p> 
							<p class='p_icon'>${getIcon(dRisk)}</p>
							<p class='p_risk'>${getRisk(dRisk)}</p> 
						</th>`;
				}
			},
		});
	}
}

// 질병코드에 따라 질병 이름 반환
function getDissCd(dissCd){
	var diseaseName;
	switch (dissCd) {
		case "1":
			diseaseName = "감기";
			break;
		case "2":
			diseaseName = "눈병";
			break;
		case "3":
			diseaseName = "식중독";
			break;
		case "4":
			diseaseName = "천식";
			break;
		case "5":
			diseaseName = "피부염";
			break;
		case "15":
			diseaseName = "심외혈관 질환";
			break;
		case "16":
			diseaseName = "온열 질환";
			break;
		default:
		    diseaseName = null;
	}
	return diseaseName;
}

// 등급에 따라 감정 아이콘 반환
function getIcon(risk){
	var icon;
	switch (risk) {
		case 1:
			icon = "<i class='fa-solid fa-face-grin-wide' style='text-shadow: green 1px 0 10px;'></i>";
			break;
		case 2:
			icon = "<i class='fa-solid fa-face-flushed' style='text-shadow: yellow 1px 0 10px;'></i>";
			break;
		case 3:
			icon = "<i class='fa-solid fa-face-tired' style='text-shadow: orange 1px 0 10px;'></i>";
			break;
		case 4:
			icon = "<i class='fa-solid fa-face-dizzy' style='text-shadow: red 1px 0 10px;'></i>";
			break;
		default:
		    icon = null;
	}
	return icon;
}

// 등급에 따라 등급 이름 반환
function getRisk(risk){
	var riskNumber;
	switch (risk) {
		case 1:
			riskNumber = "관심";
			break;
		case 2:
			riskNumber = "주의";
			break;
		case 3:
			riskNumber = "경고";
			break;
		case 4:
			riskNumber = "위험";
			break;
		default:
		    riskNumber = null;
	}
	return riskNumber;
}

// 최초 실행
searchPrediction();
