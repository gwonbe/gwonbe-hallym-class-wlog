package com.hallym.wlog;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PageController {
	
	// 날씨 페이지
	
	@RequestMapping("/weather")
	public String weather() {
	      return "weather/weather";
	}
	
	// 포스트 관련
	
	@RequestMapping("/writePost")
	public String writePost() {
		return "post/write_post";
	}
	
	// 포토 관련
	
	@RequestMapping("/savePhoto")
	public String savePhoto() {
		return "photo/save_photo";
	}
		
}
