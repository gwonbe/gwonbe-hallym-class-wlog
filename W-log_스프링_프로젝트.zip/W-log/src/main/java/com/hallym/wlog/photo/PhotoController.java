package com.hallym.wlog.photo;

import java.io.OutputStream;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/photo")
public class PhotoController {
	
	@Autowired
	PhotoService photoService;
	
	@Autowired
	PhotoFileService photoFileService;
	
	// 포토 업로드하기
	@RequestMapping("/uploadPhoto")
	public String uploadPhoto(PhotoVo photoVo, @RequestParam("file") MultipartFile file) {
		System.out.println("[PhotoController] uploadPhoto()");
		String nextPage;
		String savedFileName = photoFileService.upload(file);
		if(savedFileName != null) {
			photoVo.setPhFileName(savedFileName);
			int result = photoService.uploadPhoto(photoVo);
			nextPage = "photo/view_photo";
		}else {
			nextPage = "photo/save_photo";
		}
		return nextPage;
	}
	
	// 포토 삭제하기
	@GetMapping("/deletePhoto")
	public String deletePhoto(@RequestParam("phNumber") int phNumber) {
		System.out.println("[PhotoController] deletePhoto()");
		String nextPage;
		int result = photoService.deletePhoto(phNumber);
		if(result > 0) nextPage = "photo/photo_list";
		else nextPage = "photo/view_photo";
		return nextPage;
	}
		
	// 포토 상세 보기
	@GetMapping("/photoDetail")
	public String photoDetail(@RequestParam("phNumber") int phNumber, Model model) {
		System.out.println("[PhotoController] photoDetail()");
		String nextPage = "photo/view_photo";
		PhotoVo photoVo =photoService.photoDetail(phNumber);
		model.addAttribute("photoVo", photoVo);
		return nextPage;
	}
	
	// 포토 정보 수정 페이지로 이동하면서 상세 정보 불러오기
	@GetMapping("/modifyPhoto")
	public String modifyPhoto(@RequestParam("phNumber") int phNumber, Model model) {
		System.out.println("[PhotoController] modifyPhoto()");
		String nextPage = "photo/modify_photo";
		PhotoVo photoVo = photoService.modifyPhoto(phNumber);
		model.addAttribute("photoVo", photoVo);
		return nextPage;
	}
	
	// 포토 정보 수정하기
	@PostMapping("/modifyPhotoConfirm")
	public String modifyPhotoConfirm(PhotoVo photoVo, @RequestParam("phNumber") int phNumber, @RequestParam("file") MultipartFile file) {
		System.out.println("[PhotoController] modifyPhotoConfirm()");
		String nextPage;
		if(!file.getOriginalFilename().equals("")) {
			String savedFileName = photoFileService.upload(file);
			if(savedFileName != null) photoVo.setPhFileName(savedFileName);
		}
		int result = photoService.modifyPhotoConfirm(photoVo, phNumber);
		if(result > 0) nextPage = "photo/view_photo";
		else nextPage = "photo/modify_photo";
		return nextPage;
	}
	
	// 포토를 날씨로 검색하기
	@GetMapping("/searchPhotoWithWeather")
	public String searchPhotoWithWeather(PhotoVo photoVo, Model model) {
		System.out.println("[PhotoController] searchPhotoWithWeather()");
		String nextPage = "photo/photo_list";
		List<PhotoVo> photoVos = photoService.searchPhotoWithWeather(photoVo);
		model.addAttribute("photoVos", photoVos);
		return nextPage;
	}
	
	// 포토 리스트 페이지로 이동하면서 DB에 저장된 사진들 불러오기
	@RequestMapping("/photoList")
	public String photoList(PhotoVo photoVo, Model model) {
		System.out.println("[PhotoController] photoList()");
		String nextPage = "photo/photo_list";
		List<PhotoVo> photoVos = photoService.searchPhoto(photoVo);
		model.addAttribute("photoVos", photoVos);
		return nextPage;
	}
	
}
