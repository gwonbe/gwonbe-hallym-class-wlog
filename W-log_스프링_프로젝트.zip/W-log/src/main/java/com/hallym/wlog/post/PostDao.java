package com.hallym.wlog.post;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class PostDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	// 포스트 쓰기 - insert문
	
	public int insertPost(PostVo postVo) {
		
		System.out.println("[PostDao] insertPost()");
		
		List<String> list = new ArrayList<String>();
		
		String sql = "INSERT INTO post(pWriter,pTitle,pWeather,pContent,pDate) ";
		sql += "VALUES(?,?,?,?,NOW())";
		
		list.add(postVo.getpWriter());
		list.add(postVo.getpTitle());
		list.add(postVo.getpWeather());
		list.add(postVo.getpContent());
		list.add(postVo.getpDate());
		
		int result = -1;
		
		try {
			result = jdbcTemplate.update(sql, list.toArray());
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
		
	}
	
	// 포스트 삭제하기 - delete문
	
	public int deletePost(int pNumber) {
		
		System.out.println("[PostDao] deletePost()");
		
		String sql = "DELETE FROM post WHERE pNumber = ?";
		
		int result = -1;
		
		try {
			result = jdbcTemplate.update(sql, pNumber);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
		
	}
	
	// 포스트 읽기 - select문
	
	public PostVo selectPost(int pNumber) {
		
		System.out.println("[PostDao] selectPost()");
		
		String sql = "SELECT * FROM post WHERE pNumber = ?";
		
		List<PostVo> postVos = null;
		
		try {
			postVos = jdbcTemplate.query(
				sql, 
				new RowMapper<PostVo>() {
					@Override
					public PostVo mapRow(ResultSet rs, int rowNum) throws SQLException{
						PostVo postVo  = new PostVo();
						postVo.setpNumber(rs.getInt("pNumber"));
						postVo.setpTitle(rs.getString("pTitle"));
						postVo.setpWriter(rs.getString("pWriter"));
						postVo.setpWeather(rs.getString("pWeather"));
						postVo.setpContent(rs.getString("pContent"));
						postVo.setpDate(rs.getString("pDate"));
						return postVo;
					}
				}, 
				pNumber
			);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return postVos.size()>0 ? postVos.get(0) : null;
		
	}
	
	// 포스트 검색하기 - select문
	
	public List<PostVo> selectPostBySearch(PostVo postVo){
		
		System.out.println("[PostDao] selectPostBySearch()");
		
		String sql;
		List<PostVo> postVos;
		
		if(postVo.getpWeather() == null) {
			sql = "SELECT * FROM post ";
			sql += "WHERE pTitle LIKE ? ";
			sql += "ORDER BY pNumber DESC";
			postVos = null;
			try {
				postVos = jdbcTemplate.query(
					sql, 
					new RowMapper<PostVo>() {
						@Override
						public PostVo mapRow(ResultSet rs, int rowNum) throws SQLException{
							PostVo postVo  = new PostVo();
							postVo.setpNumber(rs.getInt("pNumber"));
							postVo.setpTitle(rs.getString("pTitle"));
							postVo.setpWriter(rs.getString("pWriter"));
							postVo.setpWeather(rs.getString("pWeather"));
							postVo.setpContent(rs.getString("pContent"));
							postVo.setpDate(rs.getString("pDate"));
							return postVo;
						}
					}, 
					"%" + postVo.getpTitle() + "%"
				);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		else {
			sql = "SELECT * FROM post ";
			sql += "WHERE pTitle LIKE ? AND pWeather LIKE ?";
			sql += "ORDER BY pNumber DESC";
			postVos = null;
			try {
				postVos = jdbcTemplate.query(
					sql, 
					new RowMapper<PostVo>() {
						@Override
						public PostVo mapRow(ResultSet rs, int rowNum) throws SQLException{
							PostVo postVo  = new PostVo();
							postVo.setpNumber(rs.getInt("pNumber"));
							postVo.setpTitle(rs.getString("pTitle"));
							postVo.setpWriter(rs.getString("pWriter"));
							postVo.setpWeather(rs.getString("pWeather"));
							postVo.setpContent(rs.getString("pContent"));
							postVo.setpDate(rs.getString("pDate"));
							return postVo;
						}
					}, 
					"%" + postVo.getpTitle() + "%",
					"%" + postVo.getpWeather() + "%"
				);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return postVos.size()>0 ? postVos : null;
		
	}
	
	// 내 블로그에서 포스트 불러오기 - select문
	
	public List<PostVo> selectMyPost(PostVo postVo, String pWriter){
		
		System.out.println("[PostDao] selectMyPost()");
		String sql = "SELECT * FROM post ";
		sql += "WHERE pWriter = ? ";
		sql += "ORDER BY pNumber DESC";
		
		List<PostVo> postVos = null;
		
		try {
			postVos = jdbcTemplate.query(
				sql, 
				new RowMapper<PostVo>() {
					@Override
					public PostVo mapRow(ResultSet rs, int rowNum) throws SQLException{
						PostVo postVo  = new PostVo();
						postVo.setpNumber(rs.getInt("pNumber"));
						postVo.setpTitle(rs.getString("pTitle"));
						postVo.setpWriter(rs.getString("pWriter"));
						postVo.setpWeather(rs.getString("pWeather"));
						postVo.setpContent(rs.getString("pContent"));
						postVo.setpDate(rs.getString("pDate"));
						return postVo;
					}
				}, 
				pWriter
			);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return postVos.size()>0 ? postVos : null;
		
	}
	
}
