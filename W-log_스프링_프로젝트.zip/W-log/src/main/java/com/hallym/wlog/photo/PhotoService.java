package com.hallym.wlog.photo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PhotoService {
		
	@Autowired
	PhotoDao photoDao;
	
	// 포토 업로드하기
	public int uploadPhoto(PhotoVo photoVo) {
		System.out.println("[PhotoService] uploadPhoto()");
		int result = photoDao.insertPhoto(photoVo);
		if(result > 0) return 1;
		else return -1;
	}
	
	// 포토 삭제하기
	public int deletePhoto(int phNumber) {
		System.out.println("[PhotoService] deletePhoto()");
		return photoDao.deletePhoto(phNumber);
	}
	
	// 포토 상세 보기
	public PhotoVo photoDetail(int phNumber) {
		System.out.println("[PhotoService] photoDetail()");
		return photoDao.selectPhoto(phNumber);
	}
	
	// 포토 정보 수정 페이지로 이동하면서 상세 정보 불러오기
	public PhotoVo modifyPhoto(int phNumber) {
		System.out.println("[PhotoService] modifyPhoto()");
		return photoDao.selectPhoto(phNumber);
	}
	
	// 포토 정보 수정하기
	public int modifyPhotoConfirm(PhotoVo photoVo, int phNumber) {
		System.out.println("[PhotoService] modifyPhotoConfirm()");
		return photoDao.updatePhoto(photoVo, phNumber);
	}
	
	// 포토를 날씨로 검색하기
	public List<PhotoVo> searchPhotoWithWeather(PhotoVo photoVo){
		System.out.println("[PhotoService] searchPhotoWithWeather()");
		return photoDao.selectPhotoWithWeather(photoVo);
	}
		
	// 포토 리스트 페이지에 DB 사진들 가져오기
	public List<PhotoVo> searchPhoto(PhotoVo photoVo){
		System.out.println("[PhotoService] searchPhoto()");
		return photoDao.selectPhoto(photoVo);
	}
	
}
