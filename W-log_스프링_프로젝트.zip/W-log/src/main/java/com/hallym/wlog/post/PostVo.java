package com.hallym.wlog.post;

public class PostVo {
	
	private int pNumber;
	private String pWriter;
	private String pTitle;
	private String pWeather;
	private String pDate;
	private String pContent;
	
	// Getters And Setters
	
	public int getpNumber() {
		return pNumber;
	}
	public void setpNumber(int pNumber) {
		this.pNumber = pNumber;
	}
	public String getpWriter() {
		return pWriter;
	}
	public void setpWriter(String pWriter) {
		this.pWriter = pWriter;
	}
	public String getpTitle() {
		return pTitle;
	}
	public void setpTitle(String pTitle) {
		this.pTitle = pTitle;
	}
	public String getpWeather() {
		return pWeather;
	}
	public void setpWeather(String pWeather) {
		this.pWeather = pWeather;
	}
	public String getpDate() {
		return pDate;
	}
	public void setpDate(String pDate) {
		this.pDate = pDate;
	}
	public String getpContent() {
		return pContent;
	}
	public void setpContent(String pContent) {
		this.pContent = pContent;
	}
		
}
