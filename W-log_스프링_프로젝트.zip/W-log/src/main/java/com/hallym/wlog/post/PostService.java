package com.hallym.wlog.post;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

@Service
public class PostService {
	
	final static public int POST_ALREADY_EXIST = 0;
	final static public int POST_CREATE_SUCCESS = 1;
	final static public int POST_CREATE_FAIL = -1;
	
	@Autowired
	PostDao postDao;
	
	// 포스트 쓰기
	public int uploadPost(PostVo postVo) {
		System.out.println("[PostService] uploadPost()");
		int uploadingPost = postDao.insertPost(postVo);
		// 결과 반환
		if(postVo == null) {
			return POST_ALREADY_EXIST;
		}else {
			if(uploadingPost > 0) return POST_CREATE_SUCCESS;
			else return POST_CREATE_FAIL;
		}
	}
	
	// 포스트 삭제하기
	public int deletePost(int pNumber) {
		System.out.println("[PostService] deletePost()");
		return postDao.deletePost(pNumber);
	}
	
	// 포스트 읽기
	public PostVo postDetail(int pNumber) {
		System.out.println("[PostService postDetail()]");
		return postDao.selectPost(pNumber);
	}
	
	// 포스트 검색하기
	public List<PostVo> searchPost(PostVo postVo){
		System.out.println("[PostService] searchPost()");
		return postDao.selectPostBySearch(postVo);
	}
	
	// 내 블로그에 포스트 가져오기
	public List<PostVo> searchMyPost(PostVo postVo, String pWriter){
		System.out.println("[PostService] searchMyPost()");
		return postDao.selectMyPost(postVo, pWriter);
	}
	
}
