package com.hallym.wlog.post;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/post")
public class PostController {
	
	@Autowired
	PostService postService;
	
	// 포스트 쓰기
	@PostMapping("/uploadPost")
	public String uploadPost(PostVo postVo) {
		System.out.println("[PostController] uploadPost()");
		int result = postService.uploadPost(postVo);
		// 결과에 따라 다음 페이지 반환
		String nextPage;
		if(result > 0) nextPage = "post/read_post";
		else nextPage = "post/write_post";
		return nextPage;
	}
	@RequestMapping("/writePost")
	public String writePost() {
		return "post/write_post";
	}
	
	// 포스트 삭제하기
	@GetMapping("/deletePost")
	public String deletePost(@RequestParam("pNumber") int pNumber) {
		System.out.println("[PostController] deletePost()");
		String nextPage;
		int result = postService.deletePost(pNumber);
		if(result > 0) nextPage = "post/post_list";
		else nextPage = "post/read_post";
		return nextPage;
	}
	
	// 포스트 읽기
	@GetMapping("/postDetail")
	public String PostDetail(@RequestParam("pNumber") int pNumber, Model model) {
		System.out.println("[PostController] postDetail()");
		String nextPage = "post/read_post";
		PostVo postVo = postService.postDetail(pNumber);
		model.addAttribute("postVo", postVo);
		return nextPage;
	}
	
	// 포스트 검색하기
	@GetMapping("/searchPost")
	public String searchPost(PostVo postVo, Model model) {
		System.out.println("[PostController] searchPost()");
		String nextPage = "post/post_list";
		List<PostVo> postVos = postService.searchPost(postVo);
		model.addAttribute("postVos", postVos);
		return nextPage;
	}
	
	// 내 블로그 페이지 이동하면서 내가 작성한 포스트 불러오기
	@RequestMapping("/myblog")
	public String myblog(PostVo postVo, Model model) {
		System.out.println("[PostController] myBlog()");
		String nextPage = "myblog/myblog";
		List<PostVo> postVos = postService.searchMyPost(postVo, "syj5179");
		model.addAttribute("postVos", postVos);
	    return nextPage;
	}
		
}
