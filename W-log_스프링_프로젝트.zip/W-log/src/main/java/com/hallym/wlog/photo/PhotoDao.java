package com.hallym.wlog.photo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.hallym.wlog.post.PostVo;

@Component
public class PhotoDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	// 포토 업로드하기 - insert문
	
	public int insertPhoto(PhotoVo photoVo) {
		
		System.out.println("[PhotoDao] insertPhoto()");
		
		String sql = "INSERT INTO photo";
		sql += "(phUser, phWeather, phTitle, phFileName, phText, phDate, phLocation, phLink) ";
		sql += ("VALUES(?, ?, ?, ?, ?, NOW(), ?, ?)");
		System.out.println(photoVo.getPhFileName());
		int result = -1;
		
		try {
			result = jdbcTemplate.update(
				sql,
				photoVo.getPhUser(),
				photoVo.getPhWeather(),
				photoVo.getPhTitle(),
				photoVo.getPhFileName(),
				photoVo.getPhText(),
				photoVo.getPhLocation(),
				photoVo.getPhLink()
			);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
		
	}
	
	// 포토 삭제하기 - delete문
	
	public int deletePhoto(int phNumber) {
		
		System.out.println("[PhotoDao] deletePhoto()");
		
		String sql = "DELETE FROM photo WHERE phNumber = ?";
		
		int result = -1;
		
		try {
			result = jdbcTemplate.update(sql, phNumber);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
		
	}
	
	// 포토 상세 보기 - select문
	
	public PhotoVo selectPhoto(int phNumber) {
		
		System.out.println("[PhotoDao] selectPhoto()");
		
		String sql = "SELECT * FROM photo WHERE phNumber = ?";
		
		List<PhotoVo> photoVos = null;
		
		try {
			photoVos = jdbcTemplate.query(
				sql, 
				new RowMapper<PhotoVo>() {
					@Override
					public PhotoVo mapRow(ResultSet rs, int rowNum) throws SQLException{
						PhotoVo photoVo = new PhotoVo();
						photoVo.setPhNumber(rs.getInt("phNumber"));
						photoVo.setPhTitle(rs.getString("phTitle"));
						photoVo.setPhUser(rs.getString("phUser"));
						photoVo.setPhFileName(rs.getString("phFileName"));
						photoVo.setPhWeather(rs.getString("phWeather"));
						photoVo.setPhText(rs.getString("phText"));
						photoVo.setPhDate(rs.getString("phDate"));
						photoVo.setPhLocation(rs.getString("phLocation"));
						photoVo.setPhLink(rs.getString("phLink"));
						return photoVo;
					}
				},
				phNumber
			);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return photoVos.size()>0 ? photoVos.get(0) : null; 
		
	}
	
	// 포토 정보 수정하기 - update문
	
	public int updatePhoto(PhotoVo photoVo, int phNumber) {
		
		System.out.println("[PhotoDao] updatePhoto()");
		
		List<String> args = new ArrayList<String> ();
		
		String sql = "UPDATE photo SET ";
		sql += "phUser = ?, phFileName = ?, phWeather = ?, phTitle = ?, phText = ?, phLocation = ?, phLink = ?, phDate = NOW()";
		sql += "WHERE phNumber = ?";
		
		args.add(photoVo.getPhUser());
		args.add(photoVo.getPhFileName());
		args.add(photoVo.getPhWeather());
		args.add(photoVo.getPhTitle());
		args.add(photoVo.getPhText());
		args.add(photoVo.getPhLocation());
		args.add(photoVo.getPhLink());
		args.add(Integer.toString(phNumber));
		
		for(int i=0; i<args.size(); i++) {
			System.out.println("~~ " + args.get(i));
		}
		
		int result = -1;
		
		try {
			result = jdbcTemplate.update(sql, args.toArray());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
		
	}
	
	// 포토를 날씨로 검색하기 - select문
	
	public List<PhotoVo> selectPhotoWithWeather(PhotoVo photoVo){
		
		System.out.println("[PhotoDao] selectPhotoBySearch()");
		
		List<PhotoVo> photoVos;
		
		if(photoVo.getPhWeather() == null) {
			photoVos = selectPhoto(photoVo);
			return photoVos.size()>0 ? photoVos : null;
		}
		else {
			String sql;
			sql = "SELECT * FROM photo ";
			sql += "WHERE phWeather LIKE ?";
			sql += "ORDER BY phNumber DESC";
			photoVos = null;
			try {
				photoVos = jdbcTemplate.query(
					sql, 
					new RowMapper<PhotoVo>() {
						@Override
						public PhotoVo mapRow(ResultSet rs, int rowNum) throws SQLException{
							PhotoVo photoVo = new PhotoVo();
							photoVo.setPhNumber(rs.getInt("phNumber"));
							photoVo.setPhTitle(rs.getString("phTitle"));
							photoVo.setPhUser(rs.getString("phUser"));
							photoVo.setPhFileName(rs.getString("phFileName"));
							photoVo.setPhWeather(rs.getString("phWeather"));
							photoVo.setPhText(rs.getString("phText"));
							photoVo.setPhDate(rs.getString("phDate"));
							photoVo.setPhLocation(rs.getString("phLocation"));
							photoVo.setPhLink(rs.getString("phLink"));
							return photoVo;
						}
					}, 
					"%" + photoVo.getPhWeather() + "%"
				);
			}catch(Exception e) {
				e.printStackTrace();
			}
			return photoVos.size()>0 ? photoVos : null;
		}
		
	}
	
	// 포토 리스트에 사진 가져오기 - select문
	
	public List<PhotoVo> selectPhoto(PhotoVo photoVo){
		
		System.out.println("[PhotoDao] selectPhoto()");
		
		String sql = "SELECT * FROM photo ORDER BY phNumber DESC";
		
		List<PhotoVo> photoVos = null;
		
		try {
			photoVos = jdbcTemplate.query(
				sql, 
				new RowMapper<PhotoVo>() {
					@Override
					public PhotoVo mapRow(ResultSet rs, int rowNum) throws SQLException{
						PhotoVo photoVo = new PhotoVo();
						photoVo.setPhNumber(rs.getInt("phNumber"));
						photoVo.setPhTitle(rs.getString("phTitle"));
						photoVo.setPhUser(rs.getString("phUser"));
						photoVo.setPhFileName(rs.getString("phFileName"));
						photoVo.setPhWeather(rs.getString("phWeather"));
						photoVo.setPhText(rs.getString("phText"));
						photoVo.setPhDate(rs.getString("phDate"));
						photoVo.setPhLocation(rs.getString("phLocation"));
						photoVo.setPhLink(rs.getString("phLink"));
						return photoVo;
					}
				}
			);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return photoVos.size()>0 ? photoVos : null;
		
	}
	
}
