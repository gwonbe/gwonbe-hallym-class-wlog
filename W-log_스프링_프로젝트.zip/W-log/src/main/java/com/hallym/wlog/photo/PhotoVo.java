package com.hallym.wlog.photo;

public class PhotoVo {
	
	private int phNumber;
	private String phUser;
	private String phTitle;
	private String phFileName;
	private String phText;
	private String phWeather;
	private String phDate;
	private String phLocation;
	private String phLink;
	
	// Getters And Setters
	
	public int getPhNumber() {
		return phNumber;
	}
	public void setPhNumber(int phNumber) {
		this.phNumber = phNumber;
	}
	public String getPhUser() {
		return phUser;
	}
	public void setPhUser(String phUser) {
		this.phUser = phUser;
	}
	public String getPhTitle() {
		return phTitle;
	}
	public void setPhTitle(String phTitle) {
		this.phTitle = phTitle;
	}
	public String getPhFileName() {
		return phFileName;
	}
	public void setPhFileName(String phFileName) {
		this.phFileName = phFileName;
	}
	public String getPhText() {
		return phText;
	}
	public void setPhText(String phText) {
		this.phText = phText;
	}
	public String getPhWeather() {
		return phWeather;
	}
	public void setPhWeather(String phWeather) {
		this.phWeather = phWeather;
	}
	public String getPhDate() {
		return phDate;
	}
	public void setPhDate(String phDate) {
		this.phDate = phDate;
	}
	public String getPhLocation() {
		return phLocation;
	}
	public void setPhLocation(String phLocation) {
		this.phLocation = phLocation;
	}
	public String getPhLink() {
		return phLink;
	}
	public void setPhLink(String phLink) {
		this.phLink = phLink;
	}
	
}
